#!/bin/bash


poetry env use $(which python3)
source $(dirname $(poetry run which python3))/activate
poetry install
